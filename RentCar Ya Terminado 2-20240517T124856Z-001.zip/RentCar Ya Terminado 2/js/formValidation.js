function validateForm() {
    // Obtener valores de los campos
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const to = document.getElementById('to').value;
    const message = document.getElementById('message').value;

    // Elementos para mostrar errores
    const nameError = document.getElementById('nameError');
    const emailError = document.getElementById('emailError');
    const toError = document.getElementById('toError');
    const messageError = document.getElementById('messageError');

    // Limpiar mensajes de error
    nameError.textContent = '';
    emailError.textContent = '';
    toError.textContent = '';
    messageError.textContent = '';

    let valid = true;

    // Validar nombre
    if (name === '') {
        nameError.textContent = 'El nombre es obligatorio.';
        valid = false;
    }

    // Validar correo electrónico
    const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    if (email === '') {
        emailError.textContent = 'El correo electrónico es obligatorio.';
        valid = false;
    } else if (!emailPattern.test(email)) {
        emailError.textContent = 'Ingrese un correo electrónico válido.';
        valid = false;
    }

    // Validar destinatario
    if (to === '') {
        toError.textContent = 'El destinatario es obligatorio.';
        valid = false;
    } else if (!emailPattern.test(to)) {
        toError.textContent = 'Ingrese un correo electrónico válido para el destinatario.';
        valid = false;
    }

    // Validar mensaje
    if (message === '') {
        messageError.textContent = 'El mensaje es obligatorio.';
        valid = false;
    }

    return valid;
}



document.getElementById('paymentForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Evita que el formulario se envíe de forma predeterminada

    // Aquí puedes agregar la lógica para procesar el pago
    alert('¡Pago procesado con éxito!');
});